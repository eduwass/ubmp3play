/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.ub.prog2.WassRosadoEduardo.controlador;
import edu.ub.prog2.utils.ReproductorBasic;

/**
 *
 * @author mat.aules
 */
public class ReproductorAudio {
    
    
    
}
